<link href="<?php echo $theme_url; ?>assets/include/slider/slider.min.css" rel="stylesheet" />
<script src="<?php echo $theme_url; ?>assets/js/details.js"></script>
<script src="<?php echo $theme_url; ?>assets/include/slider/slider.js"></script>
<link href="https://fonts.googleapis.com/css?family=Mukta+Mahee" rel="stylesheet">
<style type="text/css">
body {
  font-family: 'Mukta Mahee', sans-serif !important;
}
</style>
<?php require $themeurl.'views/socialshare.php';?>
<div class="header-mob">
  <div class="container">
    <div class="row">
      <div class="col-xs-2 col-sm-1 text-left">
        <a data-toggle="tooltip" data-placement="right" title="<?php echo trans('0533');?>" class="mt10 icon-angle-left pull-left mob-back" onclick="goBack()"></a>
      </div>
    </div>
  </div>
</div>

<div class="container">
  <h2><?=$hotel_data['hotel_name'];?></h2>
  <h4>
    <?php $stars_count = $hotel_data['stars'];
    for ($i=0; $i < $stars_count ; $i++) {
      ?>
      <i class="star fa fa-star"></i>
    <?php  } ?>
  </h4>
  <h5><?=$hotel_data['address'];?></h5>
  <div class="row">
    <div class="col-md-8">
      <div style="width:100%" class="fotorama bg-dark" data-width="1000" data-height="490" data-allowfullscreen="true" data-autoplay="true" data-nav="thumbs">
        <?php foreach($hotel_data['pictures'] as $img){ ?>
          <img style="width:100%;height:450px !important" src="<?php echo $img; ?>" />
        <?php } ?>
      </div>
    </div>
    <div class="col-md-4">
      <iframe src="http://maps.google.com/maps?q=<?=$hotel_data['lt']?>,<?=$hotel_data['lg']?>&z=15&output=embed" width="100%" height="550px" frameborder="0" style="border:0"></iframe>
    </div>
  </div>
  <br>
  <div class="sharethis-inline-share-buttons"></div>
  <br>
  <div class="row">
    <div class="col-md-12">
      <h3></h3>
      <div class="panel panel-default">
        <div class="panel-heading">
          <?php echo trans('0177'); ?>
        </div>
        <div class="panel-body">

          <p class="RTL"><strong><?=trans('055')?> : </strong></p>
          <div class="row">
            <?php if ($hotel_data['travel_agency'] == "true") { ?>
              <div class="col-md-2">
                <ul class="list_ok RTL">
                  <li>Travel Agency <!-- Translation not found --></li>
            </ul>
              </div>
            <?php } ?>

            <?php if ($hotel_data['park_auto'] == "true") { ?>
              <div class="col-md-2">
                <ul class="list_ok RTL">

                  <li>Auto Parking <!-- Translation not found --></li>
                </ul>
              </div>
            <?php } ?>

            <?php if ($hotel_data['sauna'] == "true") { ?>
              <div class="col-md-2">
                <ul class="list_ok RTL">
                  <li>Suana <!-- Translation not found --></li>
                                  </ul>
              </div>
            <?php } ?>

            <?php if ($hotel_data['film'] == "true") { ?>
              <div class="col-md-2">
                <ul class="list_ok RTL">

                  <li>Film <!-- Translation not found --></li>
                </ul>
              </div>
            <?php } ?>

            <?php if ($hotel_data['tennis'] == "true") { ?>
              <div class="col-md-2">
                <ul class="list_ok RTL">

                  <li>Tennis <!-- Translation not found --></li>
                </ul>
              </div>
            <?php } ?>

            <?php if ($hotel_data['soccer'] == "true") { ?>
              <div class="col-md-2">
                <ul class="list_ok RTL">

                  <li>Soccer <!-- Translation not found --></li>
                                  </ul>
              </div>
            <?php } ?>

            <?php if ($hotel_data['fast'] == "true") { ?>
              <div class="col-md-2">
                <ul class="list_ok RTL">

                  <li>Fast <!-- Translation not found --></li>
                                  </ul>
              </div>
            <?php } ?>

            <?php if ($hotel_data['nosmoking'] == "true") { ?>
              <div class="col-md-2">
                <ul class="list_ok RTL">
                  <li>No Smoking Rooms <!-- Translation not found --></li>
                </ul>
              </div>
            <?php } ?>

            <?php if ($hotel_data['conference'] > 0) { ?>
              <div class="col-md-2">
                <ul class="list_ok RTL">
                  <li><?=$hotel_data['conference'];?> Conference Room <!-- Translation not found --></li>
                </ul>
              </div>
            <?php } ?>

            <?php if ($hotel_data['projector'] == "true") { ?>
              <div class="col-md-2">
                <ul class="list_ok RTL">
                  <li>Projector <!-- Translation not found --></li>
                </ul>
              </div>
            <?php } ?>

            <?php if ($hotel_data['lifts'] > 0) { ?>
              <div class="col-md-2">
                <ul class="list_ok RTL">
                  <li><?=$hotel_data['lifts'];?>Lifts <!-- Translation not found --></li>
                </ul>
              </div>
            <?php } ?>

            <?php if ($hotel_data['internet'] == "true") { ?>
              <div class="col-md-2">
                <ul class="list_ok RTL">
                  <li>Internet <!-- Translation not found --></li>
                </ul>
              </div>
            <?php } ?>


            <?php if ($hotel_data['suites'] > 0) { ?>
              <div class="col-md-2">
                <ul class="list_ok RTL">
                  <li><?=$hotel_data['suites'];?> Suites <!-- Translation not found --></li>
                </ul>
              </div>
            <?php } ?>

            <?php if ($hotel_data['laundry'] == "true") { ?>
              <div class="col-md-2">
                <ul class="list_ok RTL">
                  <li>Laundry <!-- Translation not found --></li>
                </ul>
              </div>
            <?php } ?>

            <?php if ($hotel_data['beauty'] == "true") { ?>
              <div class="col-md-2">
                <ul class="list_ok RTL">
                  <li>Beauty Parlour <!-- Translation not found --></li>
                </ul>
              </div>
            <?php } ?>

            <?php if ($hotel_data['park_bus'] == "true") { ?>
              <div class="col-md-2">
                <ul class="list_ok RTL">
                  <li>Bus Parking <!-- Translation not found --></li>
                </ul>
              </div>
            <?php } ?>

            <?php if ($hotel_data['garage_auto'] == "true") { ?>
              <div class="col-md-2">
                <ul class="list_ok RTL">
                  <li>Auto Garage <!-- Translation not found --></li>
                </ul>
              </div>
            <?php } ?>

            <?php if ($hotel_data['coach_dropoff'] == "true") { ?>
              <div class="col-md-2">
                <ul class="list_ok RTL">
                  <li>Coach Dropoff <!-- Translation not found --></li>
                </ul>
              </div>
            <?php } ?>

            <?php if ($hotel_data['animals'] == "true") { ?>
              <div class="col-md-2">
                <ul class="list_ok RTL">
                  <li>Animals <!-- Translation not found --></li>
                </ul>
              </div>
            <?php } ?>

            <?php if ($hotel_data['lightboard'] == "true") { ?>
              <div class="col-md-2">
                <ul class="list_ok RTL">
                  <li>Lightbar <!-- Translation not found --></li>
                </ul>
              </div>
            <?php } ?>

            <?php if ($hotel_data['bar'] == "true") { ?>
              <div class="col-md-2">
                <ul class="list_ok RTL">
                  <li>Bar <!-- Translation not found --></li>
                </ul>
              </div>
            <?php } ?>

            <?php if ($hotel_data['shuttle_station'] == "true") { ?>
              <div class="col-md-2">
                <ul class="list_ok RTL">
                  <li>Shuttle Station <!-- Translation not found --></li>
                </ul>
              </div>
            <?php } ?>

            <?php if ($hotel_data['coach_parking'] == "true") { ?>
              <div class="col-md-2">
                <ul class="list_ok RTL">
                  <li>Coach Parking <!-- Translation not found --></li>
                </ul>
              </div>
            <?php } ?>

            <?php if ($hotel_data['pool_hot'] == "true") { ?>
              <div class="col-md-2">
                <ul class="list_ok RTL">
                  <li>Hot Pool <!-- Translation not found --></li>
                </ul>
              </div>
            <?php } ?>

            <?php if ($hotel_data['boutique'] == "true") { ?>
              <div class="col-md-2">
                <ul class="list_ok RTL">
                  <li>Boutique <!-- Translation not found --></li>
                </ul>
              </div>
            <?php } ?>

            <?php if ($hotel_data['gym'] == "true") { ?>
              <div class="col-md-2">
                <ul class="list_ok RTL">
                  <li>Gym <!-- Translation not found --></li>
                </ul>
              </div>
            <?php } ?>

            <?php if ($hotel_data['minibar'] == "true") { ?>
              <div class="col-md-2">
                <ul class="list_ok RTL">
                  <li>Minibar <!-- Translation not found --></li>
                </ul>
              </div>
            <?php } ?>

            <?php if ($hotel_data['tv'] == "true") { ?>
              <div class="col-md-2">
                <ul class="list_ok RTL">
                  <li>TV <!-- Translation not found --></li>
                </ul>
              </div>
            <?php } ?>

            <?php if ($hotel_data['pantsiron'] == "true") { ?>
              <div class="col-md-2">
                <ul class="list_ok RTL">
                  <li>Pants Iron <!-- Translation not found --></li>
                </ul>
              </div>
            <?php } ?>

            <?php if ($hotel_data['alarm'] == "true") { ?>
              <div class="col-md-2">
                <ul class="list_ok RTL">
                  <li>Alarm <!-- Translation not found --></li>
                </ul>
              </div>
            <?php } ?>

            <?php if ($hotel_data['safe'] == "true") { ?>
              <div class="col-md-2">
                <ul class="list_ok RTL">
                  <li>Safe <!-- Translation not found --></li>
                </ul>
              </div>
            <?php } ?>

            <?php if ($hotel_data['paytv'] == "true") { ?>
              <div class="col-md-2">
                <ul class="list_ok RTL">
                  <li>Pay TV <!-- Translation not found --></li>
                </ul>
              </div>
            <?php } ?>

            <?php if ($hotel_data['wifi'] == "true") { ?>
              <div class="col-md-2">
                <ul class="list_ok RTL">
                  <li>Wifi <!-- Translation not found --></li>
                </ul>
              </div>
            <?php } ?>

            <?php if ($hotel_data['rtelephone'] == "true") { ?>
              <div class="col-md-2">
                <ul class="list_ok RTL">
                  <li>Telephone <!-- Translation not found --></li>
                </ul>
              </div>
            <?php } ?>

            <?php if ($hotel_data['radio'] == "true") { ?>
              <div class="col-md-2">
                <ul class="list_ok RTL">
                  <li>Radio <!-- Translation not found --></li>
                </ul>
              </div>
            <?php } ?>
          </div>
        </div>
      </div>
    </div>
    <div class="col-md-12">
      <?php  require $themeurl.'views/modules/juniper/rooms.php'; ?>
    </div>
  </div>


<div class="container hidden-xs">
  <?php require $themeurl.'views/includes/ratinigs.php';?>
  <div class="clearfix"></div>
  <div class="clearfix"></div>
  <?php require $themeurl.'views/includes/review.php';?>
  <?php require $themeurl.'views/includes/reviews.php';?>
</div>
<script>
//------------------------------
// Write Reviews
//------------------------------
$(function(){
  $('.reviewscore').change(function(){
    var sum = 0;
    var avg = 0;
    var id = $(this).attr("id");
    $('.reviewscore_'+id+' :selected').each(function() {
      sum += Number($(this).val());
    });
    avg = sum/5;
    $("#avgall_"+id).html(avg);
    $("#overall_"+id).val(avg);
  });

      //submit review
      $(".addreview").on("click",function(){
        var id = $(this).prop("id");
        $.post("<?php echo base_url();?>admin/ajaxcalls/postreview", $("#reviews-form-"+id).serialize(), function(resp){
          var response = $.parseJSON(resp);
          // alert(response.msg);
          $("#review_result"+id).html("<div class='alert "+response.divclass+"'>"+response.msg+"</div>").fadeIn("slow");
          if(response.divclass == "alert-success"){
            setTimeout(function(){
              $("#ADDREVIEW").removeClass('in');
              $("#ADDREVIEW").slideUp();
            }, 5000);
          }
        });
        setTimeout(function(){
          $("#review_result"+id).fadeOut("slow");
        }, 3000);
      });
    })

//------------------------------
// Add to Wishlist
//------------------------------
$(function(){
      // Add/remove wishlist
      $(".wish").on('click',function(){
        var loggedin = $("#loggedin").val();
        var removelisttxt = $("#removetxt").val();
        var addlisttxt = $("#addtxt").val();
        var title = $("#itemid").val();
        var module = $("#module").val();
        if(loggedin > 0){ if($(this).hasClass('addwishlist')){
         var confirm1 = confirm("<?php echo trans('0437');?>");
         if(confirm1){
          $(".wish").removeClass('addwishlist btn-primary');
          $(".wish").addClass('removewishlist btn-warning');
          $(".wishtext").html(removelisttxt);
          $.post("<?php echo base_url();?>account/wishlist/add", { loggedin: loggedin, itemid: title,module: module }, function(theResponse){ });
        }
        return false;
      }else if($(this).hasClass('removewishlist')){
        var confirm2 = confirm("<?php echo trans('0436');?>");
        if(confirm2){
          $(".wish").addClass('addwishlist btn-primary'); $(".wish").removeClass('removewishlist btn-warning');
          $(".wishtext").html(addlisttxt);
          $.post("<?php echo base_url();?>account/wishlist/remove", { loggedin: loggedin, itemid: title,module: module }, function(theResponse){
          });
        }
        return false;
      } }else{ alert("<?php echo trans('0482');?>"); }
    });
      // End Add/remove wishlist
    })

//------------------------------
// Rooms
//------------------------------

$('.collapse').on('show.bs.collapse', function () {
  $('.collapse.in').collapse('hide');
});
<?php if($appModule == "hotels"){ ?>
  jQuery(document).ready(function($) {
    $('.showcalendar').on('change',function(){
      var roomid = $(this).prop('id');
      var monthdata = $(this).val();
      $("#roomcalendar"+roomid).html("<br><br><div id='rotatingDiv'></div>");
      $.post("<?php echo base_url();?>hotels/roomcalendar", { roomid: roomid, monthyear: monthdata}, function(theResponse){ console.log(theResponse);
        $("#roomcalendar"+roomid).html(theResponse);  }); }); });
<?php } ?>

</script>