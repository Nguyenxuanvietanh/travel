<br>
<div class="container">
	<?=$msg;?>
</div>
<br>